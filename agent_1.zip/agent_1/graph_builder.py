import re
from graph_model import Graph, Node

def build_graph(pseudocode_text, stage_metadata_list, stage_id_order):
    """
    Builds stage-to-stage graph deterministically using header stage IDs.
    `stage_id_order` is a list of header stage_ids aligned with `stage_metadata_list`.
    """

    graph = Graph()

    # -----------------------------
    # Extract stage blocks again (for edges)
    # -----------------------------
    pattern = r"// --- \[(.*?)\] ---([\s\S]*?)(?=// --- \[|$)"
    matches = re.findall(pattern, pseudocode_text)

    dataset_producer = {}   # dataset_name -> stage_id
    dataset_consumers = {}  # dataset_name -> [stage_id]

    for header, body in matches:
        parts = header.split(":")
        if len(parts) < 2:
            continue

        stage_id = parts[1].strip()

        # More robust patterns (allow extra spaces)
        inputs = re.findall(r"Input:\s*←\s*dataset_\d+\s*\(([^)]+)\)", body)
        outputs = re.findall(r"Output:\s*→\s*dataset_\d+\s*\(([^)]+)\)", body)

        for dataset in inputs:
            dataset = dataset.strip()
            dataset_consumers.setdefault(dataset, []).append(stage_id)

        for dataset in outputs:
            dataset = dataset.strip()
            dataset_producer[dataset] = stage_id

    # -----------------------------
    # Add Nodes from metadata
    # Use header stage_id for keys; keep LLM stage_name as display_name
    # -----------------------------
    for stage_id, stage_data in zip(stage_id_order, stage_metadata_list):
        if "error" in stage_data:
            # Still create a node so edges can connect; fallback display_name = stage_id
            node = Node(
                name=stage_id,
                stage_type=stage_data.get("stage_type", "Unknown"),
                summary=stage_data.get("summary", []),
                display_name=stage_data.get("stage_name", stage_id)
            )
        else:
            node = Node(
                name=stage_id,
                stage_type=stage_data["stage_type"],
                summary=stage_data["summary"],
                display_name=stage_data["stage_name"]
            )
        graph.add_node(node)

    # -----------------------------
    # Create stage-to-stage edges (only if both ends exist)
    # -----------------------------
    for dataset, producer in dataset_producer.items():
        consumers = dataset_consumers.get(dataset, [])
        for consumer in consumers:
            if producer in graph.nodes and consumer in graph.nodes:
                graph.add_edge(producer, consumer)

    return graph