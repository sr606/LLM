from collections import defaultdict, deque

def detect_pipelines(graph, include_singletons=False, group_singletons=False):
    """
    Returns list of pipelines (each is a set of stage_ids).
    - include_singletons=False: skip nodes with degree 0
    - group_singletons=True: return one extra component that contains all singletons
    """

    # Build adjacency using only existing nodes
    adjacency = defaultdict(set)

    for source, target in graph.edges:
        if source in graph.nodes and target in graph.nodes:
            adjacency[source].add(target)
            adjacency[target].add(source)  # Undirected for connectivity

    visited = set()
    pipelines = []

    # BFS over nodes that have at least one neighbor when singletons are excluded
    for node_name in graph.nodes.keys():
        if node_name in visited:
            continue

        neighbors = adjacency[node_name]
        if not include_singletons and len(neighbors) == 0 and graph.degree(node_name) == 0:
            # Skip singleton here; may add later if grouping
            continue

        queue = deque([node_name])
        component = set()

        while queue:
            current = queue.popleft()
            if current in visited:
                continue

            visited.add(current)
            component.add(current)

            for neighbor in adjacency[current]:
                if neighbor not in visited:
                    queue.append(neighbor)

        pipelines.append(component)

    if group_singletons:
        singletons = {n for n in graph.nodes.keys()
                      if graph.degree(n) == 0 and n not in visited}
        if singletons:
            pipelines.append(singletons)

    return pipelines