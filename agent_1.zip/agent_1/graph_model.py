class Node:
    def __init__(self, name, stage_type, summary, display_name=None):
        # `name` must be the stable ID from header (stage_id)
        self.name = name
        self.display_name = display_name or name  # what we show on the box label
        self.stage_type = stage_type
        self.summary = summary
        self.link_files = {}


class Graph:
    def __init__(self):
        self.nodes = {}
        self.edges = set()   # (source, target)

    def add_node(self, node: Node):
        self.nodes[node.name] = node

    def add_edge(self, source, target):
        if source != target:
            self.edges.add((source, target))

    def degree(self, node_name):
        # Count edges touching node_name
        d = 0
        for s, t in self.edges:
            if s == node_name or t == node_name:
                d += 1
        return d