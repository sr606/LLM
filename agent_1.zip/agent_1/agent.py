import os
import json
from parser import split_into_stages
from llm_service import LLMService
from pipeline_detector import detect_pipelines
from pipeline_name import generate_pipeline_name
from renderer import render_pipeline_pdf

INPUT_PATH = "../data/input/pseudocode.txt"
OUTPUT_PATH = "../data/output/metadata.json"

from graph_builder import build_graph


def run_agent():
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        pseudocode = f.read()

    # Get structured stages with header stage_id
    stages = split_into_stages(pseudocode)
    stage_id_order = [s["stage_id"] for s in stages]
    stage_blocks = [s["block"] for s in stages]

    llm = LLMService()
    metadata_results = []

    for block in stage_blocks:
        result = llm.analyze_stage(block)
        metadata_results.append(result)

    # Save metadata
    os.makedirs("../data/output", exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(metadata_results, f, indent=4)

    # Build graph with stage_id alignment
    graph = build_graph(pseudocode, metadata_results, stage_id_order)

    # Print graph info (debug)
    print("Nodes:")
    for node in graph.nodes.values():
        print("-", node.name, "| display:", node.display_name)

    print("\nEdges:")
    for edge in graph.edges:
        print("-", edge)

    pipelines = detect_pipelines(graph, include_singletons=False)  # <— NEW default
    print("\nDetected Pipelines:")
    pipeline_names = []

    for idx, pipeline in enumerate(pipelines, start=1):
        pipeline_name = generate_pipeline_name(graph, pipeline)
        pipeline_names.append(pipeline_name)
        print(f"\nPipeline {idx}: {pipeline_name}")
        for stage in pipeline:
            print("  -", stage)

    output_file = "../data/output/etl_pipeline_diagram"
    render_pipeline_pdf(graph, pipelines, pipeline_names, output_file)
    print("\nPDF Generated at:")
    print("../data/output/etl_pipeline_diagram.pdf")


if __name__ == "__main__":
    run_agent()