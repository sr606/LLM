from graphviz import Digraph


# -----------------------------
# Stage-type color palette
# -----------------------------
def stage_color(stage_type):
    palette = {
        "Extract": "#BBDEFB",      # light blue
        "Load": "#C8E6C9",         # light green
        "Transform": "#FFE0B2",    # light orange
        "Validate": "#E1BEE7",     # light purple
        "Filter": "#FFF9C4",       # light yellow
        "Join": "#B2EBF2",         # light cyan
        "Aggregate": "#DCEDC8",    # pale green
        "Enrich": "#FFCCBC",       # peach
        "Unknown": "#ECEFF1",      # gray
    }
    return palette.get(stage_type, palette["Unknown"])


# -----------------------------
# Build plain text label
# -----------------------------
def build_label(node):
    bullets = node.summary[:3] if node.summary else []

    label_lines = [
        f"{node.display_name}",
        f"({node.stage_type})",
    ]
    label_lines += [f"- {b}" for b in bullets]

    return "\n".join(label_lines)


# -----------------------------
# Add legend
# -----------------------------
def add_legend(dot, stage_types):
    """
    Legend is added as an invisible subgraph placed at bottom-right.
    No HTML, only plain text.
    """
    with dot.subgraph(name="legend") as leg:
        leg.attr(rank="sink")              # force to bottom
        leg.attr(label="Legend", style="rounded", fontsize="12", color="#B0BEC5")
        leg.node_attr.update(shape="box", style="filled,rounded", fontsize="10")

        for st in sorted(stage_types):
            leg.node(
                f"legend_{st.replace(' ', '_')}",
                st,
                fillcolor=stage_color(st),
            )


# -----------------------------
# Main renderer
# -----------------------------
def render_pipeline_pdf(
    graph,
    pipelines,
    pipeline_names,
    output_path,
    *,
    rankdir="LR",
):
    dot = Digraph("ETL_Pipelines", format="pdf")
    dot.attr(rankdir=rankdir)
    dot.attr(splines="spline")

    dot.node_attr.update(
        shape="box",
        style="filled,rounded",
        fontname="Helvetica",
        fontsize="11",
        margin="0.15,0.12"
    )
    dot.edge_attr.update(
        color="#455A64",
        arrowsize="0.7",
        fontsize="9",
        fontname="Helvetica"
    )

    # For collecting legend types
    all_stage_types = set()

    # -----------------------------
    # Clusters for pipelines
    # -----------------------------
    for idx, pipeline in enumerate(pipelines):
        cluster_name = f"cluster_{idx}"

        with dot.subgraph(name=cluster_name) as sub:
            sub.attr(
                label=f"{pipeline_names[idx]} (Stages: {len(pipeline)})",
                style="rounded",
                fontsize="12",
                color="#B0BEC5"
            )

            for stage_id in sorted(pipeline):
                node = graph.nodes.get(stage_id)
                if not node:
                    continue

                all_stage_types.add(node.stage_type or "Unknown")

                label = build_label(node)
                sub.node(
                    node.name,
                    label=label,
                    fillcolor=stage_color(node.stage_type)
                )

    # -----------------------------
    # Add edges
    # -----------------------------
    for src, tgt in sorted(graph.edges):
        if src in graph.nodes and tgt in graph.nodes:
            dot.edge(src, tgt)

    # -----------------------------
    # Add legend
    # -----------------------------
    add_legend(dot, all_stage_types)

    # -----------------------------
    # Render PDF
    # -----------------------------
    dot.render(output_path, cleanup=True)
