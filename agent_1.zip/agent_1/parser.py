import re

def split_into_stages(text: str):
    """
    Extract DataStage blocks and return structured info:
    [
      { "stage_id": "<header stage name>", "block": "<header + body>" }
    ]
    """
    pattern = r"// --- \[(.*?)\] ---([\s\S]*?)(?=// --- \[|$)"
    matches = re.findall(pattern, text)

    stages = []
    for header, body in matches:
        # header format assumed like: "Type: StageName" => we use StageName as stage_id
        parts = header.split(":")
        if len(parts) < 2:
            # Skip malformed
            continue
        stage_id = parts[1].strip()
        stage_block = f"{header}\n{body.strip()}"
        stages.append({"stage_id": stage_id, "block": stage_block})
    return stages
