def classify_step(label):
    if "Input" in label:
        return "input"
    elif "JOIN" in label:
        return "join"
    elif "Summarize" in label:
        return "analytics"
    elif "Output" in label:
        return "output"
    elif "Browse" in label:
        return "validation"
    else:
        return "processing"


def build_ir(pipelines_raw):
    ir = {}

    for pid, pdata in pipelines_raw.items():
        ir[pid] = {
            "name": pdata["name"],
            "steps": {},
            "edges": pdata["edges"]
        }

        for node_id, node_data in pdata["nodes"].items():
            step_type = classify_step(node_data["label"])

            ir[pid]["steps"][node_id] = {
                "id": node_id,
                "type": step_type,
                "label": node_data["label"]
            }

    return ir
