import re

def parse_mermaid(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()

    pipelines = {}
    current_pipeline = None

    lines = content.split("\n")

    for line in lines:
        line = line.strip()

        # Detect pipeline subgraph
        match_pipeline = re.match(r'subgraph\s+(P\d+)\["(.+)"\]', line)
        if match_pipeline:
            pipeline_id = match_pipeline.group(1)
            pipeline_name = match_pipeline.group(2)
            pipelines[pipeline_id] = {
                "name": pipeline_name,
                "nodes": {},
                "edges": []
            }
            current_pipeline = pipeline_id
            continue

        # Detect node
        match_node = re.match(r'(P\d+_S\d+)\["(.+)', line)
        if match_node and current_pipeline:
            node_id = match_node.group(1)
            label = line.split('["', 1)[1].rsplit('"]', 1)[0]

            pipelines[current_pipeline]["nodes"][node_id] = {
                "id": node_id,
                "label": label
            }
            continue

        # Detect edge
        match_edge = re.match(r'(P\d+_S\d+)\s*-->\s*(P\d+_S\d+)', line)
        if match_edge and current_pipeline:
            src = match_edge.group(1)
            dst = match_edge.group(2)
            pipelines[current_pipeline]["edges"].append((src, dst))

    return pipelines
