from mermaid_parser import parse_mermaid
from ir_builder import build_ir
from graphviz_renderer import render_graph

INPUT_FILE = "../input/workflow.mmd"

def main():
    raw = parse_mermaid(INPUT_FILE)
    ir = build_ir(raw)
    render_graph(ir)

if __name__ == "__main__":
    main()
