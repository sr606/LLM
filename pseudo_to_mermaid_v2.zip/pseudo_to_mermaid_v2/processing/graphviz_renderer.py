from graphviz import Digraph

COLOR_MAP = {
    "input": "#E3F2FD",
    "processing": "#E8F5E9",
    "join": "#FFF3E0",
    "analytics": "#F3E5F5",
    "output": "#E1F5FE",
    "validation": "#FAFAFA"
}


def render_graph(ir, output_name="workflow"):
    dot = Digraph("Workflow")
    dot.attr(rankdir="TB")

    for pid, pdata in ir.items():
        with dot.subgraph(name=f"cluster_{pid}") as cluster:
            cluster.attr(label=pdata["name"])

            for step_id, step in pdata["steps"].items():
                color = COLOR_MAP.get(step["type"], "#FFFFFF")

                clean_label = step["label"].replace("\n", "<br/>")
                label_html = f"""
                <
                <table border="0" cellborder="1" cellspacing="0" cellpadding="6" bgcolor="{color}">
                    <tr><td align="left">{clean_label}</td></tr>
                </table>
                >
                """


                cluster.node(step_id, label=label_html, shape="plain")

            for src, dst in pdata["edges"]:
                cluster.edge(src, dst)

    dot.render(f"output/{output_name}", format="svg", cleanup=True)
    dot.render(f"output/{output_name}", format="pdf", cleanup=True)

    print("Diagram generated.")
