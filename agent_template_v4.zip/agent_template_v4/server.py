from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from contextlib import asynccontextmanager

from routers.v1 import handler as h1
# from routers.v1 import handler2 as h2

from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
import routers.v1.agent_checkpointer as agent_checkpointer


@asynccontextmanager
async def lifespan(app: FastAPI):
    # 🔥 CREATE saver (DO NOT use async with here)
    saver_cm = AsyncPostgresSaver.from_conn_string(agent_checkpointer.DB_URI)
    saver = await saver_cm.__aenter__()

    await saver.setup()
    agent_checkpointer.checkpointer = saver
    print("✅ Postgres checkpointer initialized")

    try:
        yield
    finally:
        # 🔥 CLEAN SHUTDOWN
        await saver_cm.__aexit__(None, None, None)
        agent_checkpointer.checkpointer = None
        print("🛑 Postgres checkpointer closed")


app = FastAPI(
    title="Agent Server",
    lifespan=lifespan
)


# ------------------------------------------------------------------
# CORS
# ------------------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ------------------------------------------------------------------
# ROUTERS
# ------------------------------------------------------------------
app.include_router(h1.router, prefix="/v1")
# app.include_router(h2.router, prefix="/v2")



# ------------------------------------------------------------------
# MAIN
# ------------------------------------------------------------------
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=3658)
