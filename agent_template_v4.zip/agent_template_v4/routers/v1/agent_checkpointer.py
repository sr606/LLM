# agent_checkpointer.py
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
import os
from dotenv import load_dotenv

load_dotenv()

DB_URI = os.environ["DB_URI"]

checkpointer: AsyncPostgresSaver | None = None