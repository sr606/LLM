from langchain_core.messages import (
    SystemMessage,
    BaseMessage,
    HumanMessage,
    AIMessage,
    ToolMessage,
    AIMessageChunk
)
import os
import json
from .agent_state import State
import httpx
from langchain_core.runnables import RunnableConfig, ConfigurableField
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

AGENT_API_BASE = os.environ["AGENT_API_BASE"]
AGENT_API_KEY = os.environ["AGENT_API_KEY"]

async def llm_intel(state: State, config: RunnableConfig, llm_with_tools, system_msg):
    sanitized_messages = []
    for msg in state["messages"]:
        if isinstance(msg, ToolMessage):
            content = msg.content
            if not isinstance(content, str):
                content = json.dumps(content)

            sanitized_messages.append(ToolMessage(
                tool_call_id=msg.tool_call_id,
                content=content
            ))
        else:
            sanitized_messages.append(msg)

    prompt = ChatPromptTemplate.from_messages([
        SystemMessage(content=system_msg),
        MessagesPlaceholder(variable_name="context", optional=True),
    ])
    
    messages = prompt.format_messages(context=sanitized_messages)
    
    final_msg = None
    async for chunk in llm_with_tools.astream(messages):
        yield {"messages": []}
        final_msg = chunk if final_msg is None else final_msg + chunk
        
    if final_msg:
        yield {"messages": [final_msg]}

async def agent_call_node(state: State, config: RunnableConfig, model_source, temperature):
    last_msg = state["messages"][-1]
    # print(last_msg)
    try:
        payload = json.loads(last_msg.content)
    except Exception as e:
        print(e)
        return

    if payload.get("type") != "Agent_Call":
        return

    target_agent_name = payload.get("Agent_name")
    agent_message = payload.get("message", "")
    print('calling agent ===',target_agent_name)
    yield(f'\n\n#### Calling Agent :  {target_agent_name}\n\n')
    if not target_agent_name:
        state["messages"].append(
            AIMessage(content="Agent_Call missing Agent_name")
        )
        return

    thread_id = config["configurable"]["thread_id"]
    user_id = config["configurable"]["user_id"]

    request_payload = {
        "query": agent_message,
        "thread_id": thread_id,
        "agent_name": target_agent_name.lower(),
        "temperature":temperature,
        "model_source":model_source
    }

    headers = {
        "X-API-Key": AGENT_API_KEY,
        "Content-Type": "application/json"
    }

    final_content = ""

    async with httpx.AsyncClient(timeout=None) as client:
        async with client.stream(
            "POST",
            AGENT_API_BASE,
            json=request_payload,
            headers=headers,
        ) as response:

            async for chunk in response.aiter_text():
                if not chunk:
                    continue

                final_content += chunk

                yield {
                        "delegated": target_agent_name,
                        "content": chunk
                    }

    # Append final AI message to state
    if final_content.strip():
        state["messages"].append(
            AIMessage(
                content=final_content,
                additional_kwargs={
                    "delegated_agent": target_agent_name
                }
            )
        )

    return