
import os
import asyncio
import asyncpg
import json
from dotenv import load_dotenv
from langchain_mcp_adapters.client import MultiServerMCPClient

load_dotenv()

# --------------------------------------------------------------------------
# MCP CONFIG 
# --------------------------------------------------------------------------
async def get_mcp_config(agent_name: str,agent_session_id: str) -> dict:
    
    """
    Fetch MCP server configuration for the given agent from PostgreSQL.

    Returns a dict compatible with MultiServerMCPClient:
    {
      "<server_name>": {
          "url": "<server_url>",
          "transport": "<transport>",
          "headers": { ... }  # JSONB in DB
      },
      ...
    }
    """
    result = {}

    # Read DB connection settings
    pg_host = os.getenv("POSTGRES_HOST", "localhost")
    pg_port = int(os.getenv("POSTGRES_PORT", "5432"))
    pg_db   = os.getenv("POSTGRES_DB", "omnicore")
    pg_user = os.getenv("POSTGRES_USER", "omnicore")
    pg_pass = os.getenv("POSTGRES_PASSWORD", "omnicore")

    conn = None
    try:
        conn = await asyncpg.connect(
            host=pg_host,
            port=pg_port,
            user=pg_user,
            password=pg_pass,
            database=pg_db,
        )
        await conn.set_type_codec('json',  schema='pg_catalog',
                          encoder=json.dumps, decoder=json.loads, format='text')
        await conn.set_type_codec('jsonb', schema='pg_catalog',
                          encoder=json.dumps, decoder=json.loads, format='text')

        rows = await conn.fetch("""
            SELECT server_name, url, transport, headers
            FROM agent_config
            WHERE agent_name = $1
        """, agent_name)

        for row in rows:
            server_name = row["server_name"]
            server_url = row["url"]
            transport = row["transport"]
            headers = row["headers"] or {}
            
            headers["X-Agent-Session-Id"] = agent_session_id
            
            result[server_name] = {
                "url": server_url,
                "transport": transport,  
                "headers": headers,      
            }
    except Exception as e:
        print(f"[get_mcp_config:postgres][ERROR] {e}")
    finally:
        if conn:
            await conn.close()

    return result

async def get_tool_list(agent_name: str, agent_session_id: str):
    config_mcp_server = await get_mcp_config(agent_name,agent_session_id)

    if not config_mcp_server:
        raise RuntimeError("No MCP servers configured")

    client = MultiServerMCPClient(config_mcp_server)
    tools_list = await client.get_tools()

    return tools_list


# --------------------------------------------------------------------------
#  test runner
# --------------------------------------------------------------------------
# if __name__ == "__main__":
#     async def _test():
#         tools = await get_tool_list("db_details")  # change to your agent name if needed
#         print("TOOLS COUNT:", len(tools))

#     asyncio.run(_test())
