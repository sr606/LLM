import asyncio
import os
from dotenv import load_dotenv
import httpx

load_dotenv()

API_URL = os.environ["AGENT_API_BASE"]
API_KEY = os.environ["AGENT_API_KEY"]

async def stream_chat(payload):
    headers = {
        "X-API-Key": API_KEY
    }

    async with httpx.AsyncClient(timeout=None) as client:
        async with client.stream(
            "POST",
            API_URL,
            json=payload,
            headers=headers
        ) as response:

            if response.status_code != 200:
                error_text = await response.aread()
                print("Error:", error_text.decode())
                return

            async for chunk in response.aiter_text():
                if chunk:
                    print(chunk, end="", flush=True)


if __name__ == "__main__":
    # payload = {
    #     "query": "can you calculate the sum of 25 and 62?",
    #     # "query": "list me the tools available ?",
    #     "thread_id": "1004",
    #     "agent_name": "test3",
    #     "temperature":0.00,
    #     "model_source":'azure'
    # }

    # asyncio.run(stream_chat(payload))


    payload = {
        "query": "can you list me the tables in the database?",
        # "query": "list me the tools available ?",
        "thread_id": "1004",
        "agent_name": "test3",
        "temperature":0.00,
        "model_source":'azure'
    }

    asyncio.run(stream_chat(payload))