from graphviz import Digraph
from collections import defaultdict


def compute_levels(graph, pipeline):
    """
    Compute stage levels for left-to-right layout.
    """

    incoming_count = {stage: 0 for stage in pipeline}

    for edge in graph.edges:
        target = edge["target"]
        if target in incoming_count:
            incoming_count[target] += 1

    levels = {}
    current_level = 0
    frontier = [stage for stage, count in incoming_count.items() if count == 0]

    visited = set()

    while frontier:
        next_frontier = []

        for stage in frontier:
            levels[stage] = current_level
            visited.add(stage)

            for edge in graph.edges:
                source = edge["source"]
                target = edge["target"]
                if source == stage and target in pipeline:
                    if target not in visited:
                        next_frontier.append(target)

        frontier = list(set(next_frontier))
        current_level += 1

    return levels


def render_pipeline_pdf(graph, pipelines, pipeline_names, output_path):

    dot = Digraph("ETL_Pipelines", format="pdf")
    # dot.attr(rankdir="LR", size="12,8")
    dot.attr(compound="true")

    for idx, pipeline in enumerate(pipelines):

        levels = compute_levels(graph, pipeline)

        with dot.subgraph(name=f"cluster_{idx}") as sub:
            sub.attr(label=pipeline_names[idx], style="rounded", fontsize="16")

            level_groups = defaultdict(list)
            for stage, level in levels.items():
                level_groups[level].append(stage)

            for level, stages in level_groups.items():
                with sub.subgraph() as level_sub:
                    level_sub.attr(rank="same")

                    for stage_name in stages:
                        node = graph.nodes[stage_name]

                        # Choose shape + color
                        shape = "box"
                        fillcolor = "white"

                        if "Oracle" in node.stage_type:
                            shape = "cylinder"
                            fillcolor = "#cce5ff"

                        elif "Transformer" in node.stage_type:
                            shape = "box"
                            fillcolor = "#fff3cd"

                        elif "Hashed" in node.stage_type:
                            shape = "folder"
                            fillcolor = "#e2e3e5"

                        elif "SeqFile" in node.stage_type:
                            shape = "note"
                            fillcolor = "#d4edda"

                        # Build label (limit bullets)
                        label = f"{node.name}\n({node.stage_type})\n"

                        for bullet in node.summary[:3]:
                            short = bullet[:80]
                            label += f"• {short}\n"

                        level_sub.node(
                            node.name,
                            label=label,
                            shape=shape,
                            style="filled",
                            fillcolor=fillcolor
                        )

    # Global edges
    for edge in graph.edges:
        source = edge["source"]
        target = edge["target"]
        edge_type = edge["type"]
 
        if edge_type == "main":
            dot.edge(source, target, constraint="true")
 
        # else:  # lookup/reference
        #     dot.edge(
        #     source,
        #     target,
        #     style="dashed",
        #     constraint="false"
        # )

    dot.render(output_path, cleanup=True)
