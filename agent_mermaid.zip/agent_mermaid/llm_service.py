import os
import json
from dotenv import load_dotenv
from openai import AzureOpenAI
 
load_dotenv()
 
 
class LLMService:
    def __init__(self):
 
        self.client = AzureOpenAI(
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
            azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        )
 
        self.deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT")
 
        self.system_prompt = """
You are an ETL Stage Analyzer.
 
You MUST return ONLY a valid JSON object.
Do not include markdown.
Do not include explanations.
Do not include text before or after JSON.
 
Return format:
 
{
  "stage_name": "string",
  "stage_type": "string",
  "summary": ["bullet1", "bullet2", "bullet3"]
}
"""
 
    # -------------------------------
    # Robust JSON Extractor
    # -------------------------------
    def _extract_json_object(self, text: str):
        stack = []
        start = None
 
        for i, char in enumerate(text):
            if char == "{":
                if start is None:
                    start = i
                stack.append(char)
            elif char == "}":
                if stack:
                    stack.pop()
                    if not stack:
                        return text[start:i+1]
 
        return None
 
    # -------------------------------
    # Stage Analyzer
    # -------------------------------
    def analyze_stage(self, stage_block: str):
 
        response = self.client.chat.completions.create(
            model=self.deployment,
            temperature=0.0,
            messages=[
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": stage_block}
            ],
        )
 
        raw_text = response.choices[0].message.content.strip()
 
        json_text = self._extract_json_object(raw_text)
 
        if not json_text:
            return {
                "error": "No JSON object detected",
                "raw_response": raw_text
            }
 
        try:
            parsed = json.loads(json_text)
 
            # Validate required keys
            if not all(k in parsed for k in ["stage_name", "stage_type", "summary"]):
                return {
                    "error": "Missing required keys",
                    "raw_json": json_text
                }
 
            return parsed
 
        except Exception as e:
            return {
                "error": "JSON parsing failed",
                "exception": str(e),
                "raw_json": json_text
            }