from llm_service import LLMService


def generate_pipeline_name(graph, pipeline_stages):
    """
    Hybrid pipeline naming.
    pipeline_stages: set of stage names
    """

    # ---------------------------
    # Step 1: Deterministic Fallback
    # ---------------------------

    # Find source stages (no incoming edges)
    incoming = {stage: 0 for stage in pipeline_stages}

    for edge in graph.edges:
        source = edge["source"]
        target = edge["target"]
        if target in incoming:
            incoming[target] += 1

    source_candidates = [stage for stage, count in incoming.items() if count == 0]

    if source_candidates:
        fallback_name = source_candidates[0]
    else:
        fallback_name = list(pipeline_stages)[0]

    # ---------------------------
    # Step 2: Build Structured Summary
    # ---------------------------

    pipeline_summary = []

    for stage in pipeline_stages:
        node = graph.nodes.get(stage)
        if not node:
            continue

        pipeline_summary.append({
            "stage_name": node.name,
            "stage_type": node.stage_type,
            "summary": node.summary
        })

    # ---------------------------
    # Step 3: Ask LLM For Better Name
    # ---------------------------

    llm = LLMService()

    prompt = f"""
You are generating a professional ETL pipeline name.

Based on the following structured pipeline stages,
generate a short professional name (max 6 words).

Return ONLY the name as plain text.
No explanation.

Pipeline Data:
{pipeline_summary}
"""

    try:
        response = llm.client.chat.completions.create(
            model=llm.deployment,
            temperature=0.0,
            messages=[
                {"role": "system", "content": "You generate concise pipeline names."},
                {"role": "user", "content": prompt}
            ],
        )

        name = response.choices[0].message.content.strip()

        # Basic cleanup
        name = name.replace("\n", "").strip()

        if len(name) > 2:
            return name

    except Exception:
        pass

    # ---------------------------
    # Step 4: Fallback
    # ---------------------------

    return fallback_name