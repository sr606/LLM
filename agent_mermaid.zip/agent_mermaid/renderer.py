from graphviz import Digraph


def render_pipeline_pdf(graph, pipelines, pipeline_names, output_path):
    """
    Renders clustered pipeline diagram into PDF.
    """

    dot = Digraph("ETL_Pipelines", format="pdf")
    dot.attr(rankdir="LR", size="8,5")

    # -----------------------------------
    # Create clusters per pipeline
    # -----------------------------------
    for idx, pipeline in enumerate(pipelines):

        cluster_name = f"cluster_{idx}"

        with dot.subgraph(name=cluster_name) as sub:

            sub.attr(label=pipeline_names[idx], style="rounded")

            for stage_name in pipeline:
                node = graph.nodes.get(stage_name)

                if not node:
                    continue

                # Build node label
                label = f"{node.name}\n({node.stage_type})\n"

                for bullet in node.summary[:4]:
                    label += f"• {bullet}\n"

                # Optional: include link file bindings
                if node.link_files:
                    label += "\nLink Files:\n"
                    for link, file in node.link_files.items():
                        label += f"{link} → {file}\n"

                sub.node(
                    node.name,
                    label=label,
                    shape="box"
                )

    # -----------------------------------
    # Add edges globally
    # -----------------------------------
    for source, target in graph.edges:
        dot.edge(source, target)

    # -----------------------------------
    # Render file
    # -----------------------------------
    dot.render(output_path, cleanup=True)