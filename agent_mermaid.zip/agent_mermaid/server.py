from fastapi import FastAPI
from agent import run_agent

app = FastAPI()

@app.post("/generate-diagram")
def generate():
    run_agent()
    return {"status": "success", "message": "Metadata generated"}
