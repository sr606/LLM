import re
 
def split_into_stages(text: str):
    """
    Extract only valid DataStage stage blocks.
    Ignore file headers and other comments.
    """
 
    pattern = r"// --- \[(.*?)\] ---([\s\S]*?)(?=// --- \[|$)"
 
    matches = re.findall(pattern, text)
 
    stage_blocks = []
 
    for header, body in matches:
        stage_block = f"{header}\n{body.strip()}"
        stage_blocks.append(stage_block)
 
    return stage_blocks