# import re
# from graph_model import Graph, Node


# def build_graph(pseudocode_text, stage_metadata_list):
#     """
#     Builds stage-to-stage graph deterministically.
#     """

#     graph = Graph()

#     # -----------------------------
#     # Extract stage blocks again
#     # -----------------------------
#     pattern = r"// --- \[(.*?)\] ---([\s\S]*?)(?=// --- \[|$)"
#     matches = re.findall(pattern, pseudocode_text)

#     dataset_producer = {}  # dataset_name -> stage_name
#     dataset_consumers = {}  # dataset_name -> [stage_names]
#     stage_link_file_map = {} #stage_name -> {link: file}

#     for header, body in matches:

#         print("\n=================")
#         print("HEADER", header)
#         print("BODY SNIPPT:")
#         print(body[:300])

#         parts = header.split(":")
#         if len(parts) < 2:
#             continue

#         stage_name = parts[1].strip()

#         # Extract inputs
#         inputs = [m.strip() for m in re.findall(r"Input:\s*←\s*dataset_\d+\s*\((.*?)\)", body)]

#         for dataset in inputs:
#             dataset_consumers.setdefault(dataset, []).append(stage_name)

#         # Extract outputs
#         outputs = [m.strip() for m in re.findall(r"Output:\s*→\s*dataset_\d+\s*\((.*?)\)", body)]

#         for dataset in outputs:
#             dataset_producer[dataset] = stage_name

#         # Extract link-file bindings
#         # link_file_matches = re.findall(r'^\s*Link File\s*\(([^)]+)\)\s*:\s*(.+)$',body,
#         # flags=re.MULTILINE)
#         pattern = r'Link File\s*\(([^)]+)\)\s*:\s*(.*?)(?=\s*Link File\s*\(|$)'
#         link_file_matches = re.findall(pattern, body, flags=re.DOTALL)

#         stage_link_files = {name.strip(): value.strip() for name, value in link_file_matches}
#         # for link_name, file_name in link_file_matches:
#         #     stage_link_files[link_name.strip()] = file_name.strip()

#         # link_file_matches = re.findall(r"\s*Link File\s*\((.*?)\)\s*:(s*(.+",body)

#         # stage_link_files = {}
#         # for link_name, file_name in link_file_matches:
#         #     stage_link_files[link_name.strip()] = file_name.strip()

#         stage_link_file_map[stage_name] = stage_link_files

#     # -----------------------------
#     # Add Nodes from metadata
#     # -----------------------------
#     for stage_data in stage_metadata_list:

#         if "error" in stage_data:
#             continue

#         stage_name = stage_data["stage_name"]

#         node = Node(
#             name=stage_name,
#             stage_type=stage_data["stage_type"],
#             summary=stage_data["summary"]
#         )

#         #attach link-file metadata here
#         node.link_files = stage_link_file_map.get(stage_name, {})

#         print("Header stage:", stage_name, "| LLM stage:", stage_data["stage_name"])

#         graph.add_node(node)

#     # -----------------------------
#     # Create stage-to-stage edges
#     # -----------------------------
#     for dataset, producer in dataset_producer.items():
#         consumers = dataset_consumers.get(dataset, [])

#         for consumer in consumers:
#             graph.add_edge(producer, consumer)

#     return graph

import re
from graph_model import Graph, Node

def build_graph(pseudocode_text, stage_metadata_list):
    """
    Builds stage-to-stage graph deterministically.
    """

    graph = Graph()

    # -----------------------------
    # Extract stage blocks again
    # -----------------------------
    pattern = r"// --- \[(.*?)\] ---([\s\S]*?)(?=// --- \[|$)"
    matches = re.findall(pattern, pseudocode_text)

    dataset_producer = {}   # dataset_name -> stage_name
    dataset_consumers = {}  # dataset_name -> [stage_names]
    stage_link_file_map = {}  # stage_name -> {link: file}

    for header, body in matches:
        print("\n=================")
        print("HEADER", header)
        print("BODY SNIPPET:")
        print(body[:300])

        # Safer split: only on first ':'
        parts = header.split(":", 1)
        if len(parts) < 2:
            # header format unexpected, skip
            continue

        # Extract and normalize header stage name
        header_stage_name = parts[1].strip()
        # Remove trailing bracketed annotations like "] [Lines 171-476"
        header_stage_name = re.sub(r'\]\s*\[.*$', '', header_stage_name).strip()

        # Extract inputs (strip dataset names)
        inputs = [m.strip() for m in re.findall(r"Input:\s*←\s*dataset_\d+\s*\((.*?)\)", body)]
        for dataset in inputs:
            dataset_consumers.setdefault(dataset, []).append(header_stage_name)

        # Extract outputs (strip dataset names)
        outputs = [m.strip() for m in re.findall(r"Output:\s*→\s*dataset_\d+\s*\((.*?)\)", body)]
        for dataset in outputs:
            dataset_producer[dataset] = header_stage_name

        # Extract link-file bindings (handles multiple on one line and across lines)
        link_file_matches = re.findall(
            r'Link File\s*\(([^)]+)\)\s*:\s*(.*?)(?=\s*Link File\s*\(|^\s*Output\s*:|$)',
            body,
            flags=re.DOTALL | re.MULTILINE
        )

        stage_link_files = {name.strip(): value.strip() for name, value in link_file_matches}
        stage_link_file_map[header_stage_name] = stage_link_files

        # Helpful debug
        if not stage_link_files:
            print(f"[DEBUG] No Link File matches in stage: {header_stage_name!r}")
        else:
            print(f"[DEBUG] Link files for {header_stage_name!r}: {stage_link_files}")

    # -----------------------------
    # Add Nodes from metadata
    # -----------------------------
    for stage_data in stage_metadata_list:
        if "error" in stage_data:
            continue

        meta_stage_name = stage_data["stage_name"]

        node = Node(
            name=meta_stage_name,
            stage_type=stage_data["stage_type"],
            summary=stage_data["summary"]
        )

        # Attach link-file metadata using normalized header name as key
        node.link_files = stage_link_file_map.get(meta_stage_name, {})

        # Real comparison: show header-vs-LLM mapping result
        print("LLM stage:", meta_stage_name, "| link files attached:", bool(node.link_files))

        graph.add_node(node)

    # -----------------------------
    # Create stage-to-stage edges
    # -----------------------------
    for dataset, producer in dataset_producer.items():
        consumers = dataset_consumers.get(dataset, [])
        for consumer in consumers:
            # if producer in graph.nodes and consumer in graph.nodes:
            #     graph.add_edge(producer, consumer)
            # else:
            #     # Useful warnings to detect any remaining naming mismatches
            #     if producer not in graph.nodes:
            #         print(f"[WARN] Producer node missing: {producer!r}")
            #     if consumer not in graph.nodes:
            #         print(f"[WARN] Consumer node missing: {consumer!r}")

            # Determine edge type
            producer_node = graph.nodes.get(producer)
            consumer_node = graph.nodes.get(consumer)
 
            edge_type = "main"
 
            # If producer is a lookup/hash stage
            if producer_node and (
                "Hashed" in producer_node.stage_type or
                "Lkp" in producer_node.name
                ):
                edge_type = "lookup"
 
            graph.add_edge(producer, consumer, edge_type=edge_type)

    return graph