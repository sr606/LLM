import os
import json
from parser import split_into_stages
from llm_service import LLMService
from pipeline_detector import detect_pipelines
from pipeline_name import generate_pipeline_name
from renderer import render_pipeline_pdf


INPUT_PATH = "../data/input/pseudocode.txt"
OUTPUT_PATH = "../data/output/metadata.json"


from graph_builder import build_graph


def run_agent():

    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        pseudocode = f.read()

    stage_blocks = split_into_stages(pseudocode)

    llm = LLMService()
    metadata_results = []

    for block in stage_blocks:
        result = llm.analyze_stage(block)
        metadata_results.append(result)

    # Save metadata
    os.makedirs("../data/output", exist_ok=True)

    with open("../data/output/metadata.json", "w", encoding="utf-8") as f:
        json.dump(metadata_results, f, indent=4)

    # Build graph
    graph = build_graph(pseudocode, metadata_results)

    print("\n================ GRAPH DEBUG ================\n")
    print("Nodes:")
    for node in graph.nodes.values():
        print(f"\nStage: {node.name}")
        print(f"  Type: {node.stage_type}")
        print(f"  Summary: {node.summary}")
        
        if node.link_files:
            print("  Link File Bindings:")
            for link, file in node.link_files.items():
                print(f"    {link} -> {file}")
        else:
            print("  Link File Bindings: NONE")
 
    print("\nEdges:")
    for edge in graph.edges:
        # print(f"  {source}  -->  {target}")
 
        print("\n============================================\n")

    # Print graph info
    # print("\nLink File Bindings:")
    # for node in graph.nodes.values():
    #     if node.link_files:
    #         print(f"{node.name}:")
    #         for link,file in node.link_files.items():
    #             print(f"  {link} -> {file}")

    # print("\nEdges:")
    # for edge in graph.edges:
    #     print("-", edge)

    pipelines = detect_pipelines(graph)
    # print("\nDetected Pipelines:")
    # for idx, pipeline in enumerate(pipelines, start=1):
    #     print(f"\nPipeline {idx}:")
    #     for stage in pipeline:
    #         print("  -", stage)

    print("\nDetected Pipelines:")
    for idx, pipeline in enumerate(pipelines, start=1):
        pipeline_name = generate_pipeline_name(graph, pipeline)
        print(f"\nPipeline {idx}: {pipeline_name}")
        for stage in pipeline:
            print("  -", stage)

    pipeline_names = []
    for pipeline in pipelines:
        name = generate_pipeline_name(graph, pipeline)
        pipeline_names.append(name)


    output_file = "../data/output/etl_pipeline_diagram"
    render_pipeline_pdf(
        graph,
        pipelines,
        pipeline_names,
        output_file)
    print("\nPDF Generated at:")
    print("../data/output/etl_pipeline_diagram.pdf")

    

if __name__ == "__main__":
    run_agent()