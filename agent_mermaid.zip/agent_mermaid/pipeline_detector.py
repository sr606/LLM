from collections import defaultdict, deque


def detect_pipelines(graph):
    """
    Returns list of pipelines.
    Each pipeline is a set of stage names.
    """

    # Build adjacency list
    adjacency = defaultdict(set)

    for edge in graph.edges:
        source = edge["source"]
        target = edge["target"]
        adjacency[source].add(target)
        adjacency[target].add(source)  # Undirected for connectivity

    visited = set()
    pipelines = []

    for node_name in graph.nodes.keys():

        if node_name in visited:
            continue

        queue = deque([node_name])
        component = set()

        while queue:
            current = queue.popleft()

            if current in visited:
                continue

            visited.add(current)
            component.add(current)

            for neighbor in adjacency[current]:
                if neighbor not in visited:
                    queue.append(neighbor)

        pipelines.append(component)

    return pipelines
