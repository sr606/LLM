class Node:
    def __init__(self, name, stage_type, summary):
        self.name = name
        self.stage_type = stage_type
        self.summary = summary
        self.link_files = {}


class Graph:
    def __init__(self):
        self.nodes = {}
        # self.edges = set()   # (source, target)
        self.edges = []

    def add_node(self, node: Node):
        self.nodes[node.name] = node

    def add_edge(self, source, target, edge_type="main"):
        if source != target:
            # self.edges.add((source, target))
            self.edges.append({
                "source": source,
                "target": target,
                "type": edge_type
            })
