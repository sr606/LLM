from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from settings import settings

DB_URI = settings.DB_URI

checkpointer: AsyncPostgresSaver | None = None