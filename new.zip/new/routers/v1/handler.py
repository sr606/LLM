from fastapi import APIRouter
from pydantic import BaseModel
from phoenix.otel import register
from settings import settings
from routers.v1 import agent as agent
from openinference.instrumentation import using_attributes
from fastapi.responses import StreamingResponse
from fastapi import APIRouter, Depends
import json
from auth.auth import get_current_user

router = APIRouter()

class InputData(BaseModel):
    query: str
    thread_id: str
    agent_name: str
    temperature:float
    model_source:str

async def get_response(msg, session_id, agent_name, user_id, temperature, model_source):
    o_agent = await agent.create_agent(agent_name, model_source, session_id)

    async for event in o_agent.run(
        message=msg,
        thread_id=session_id,
        user_id=user_id,
        temperature=temperature
    ):
        # --- 1. Main Agent's LLM Chunks ---
        if event["event"] == "on_chat_model_stream":
            content = event["data"]["chunk"].content
            if isinstance(content, str):
                yield content
            # Case 2: content is a list (e.g. [{"text": "..."}])
            elif isinstance(content, list) and content:
                value = content[0].get("text")
                if value:
                    yield value

        # --- 2. Delegated Agent's Chunks (Includes its Tools & Text) ---
        elif event["event"] == "on_chain_stream":
            chunk = event.get("data", {}).get("chunk")

            if isinstance(chunk, dict) and "delegated" in chunk:
                yield f"{chunk['content']}"

        # --- 3. Main Agent's Tool Events ---
        elif event["event"] == "on_tool_start":
            yield f'\n\n##### Calling Tool: {event["name"]}\n\n'
            yield f'###### Tool Input \n\n {event["data"]["input"]}\n\n'

        elif event["event"] == "on_tool_end":
            output = event["data"]["output"].content
            if not isinstance(output, str):
                output = json.dumps(output, ensure_ascii=False)
            yield f"###### Tool Output \n\n {output}\n\n"


@router.post("/chat")
async def chat_stream(input: InputData, userinfo: str = Depends(get_current_user)):
    tracer_provider = register(
        project_name=input.agent_name,
        auto_instrument=True,
        batch=True,
        endpoint=settings.TRACE_URL,
        api_key= settings.PHOENIX_API_KEY
    )
    return StreamingResponse(
        get_response(
            msg=input.query,
            session_id=input.thread_id,
            agent_name=input.agent_name,
            user_id=userinfo['sub'],
            temperature = input.temperature,
            model_source = input.model_source
        ),
        media_type="text/event-stream"
    )
