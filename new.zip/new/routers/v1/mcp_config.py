
import os
import asyncio
import asyncpg
import json
from settings import settings
from langchain_mcp_adapters.client import MultiServerMCPClient


# --------------------------------------------------------------------------
# MCP CONFIG 
# --------------------------------------------------------------------------
async def get_mcp_config(agent_name: str,agent_session_id: str) -> dict:
    
    """
    Fetch MCP server configuration for the given agent from PostgreSQL.

    Returns a dict compatible with MultiServerMCPClient:
    {
      "<server_name>": {
          "url": "<server_url>",
          "transport": "<transport>",
          "headers": { ... }  # JSONB in DB
      },
      ...
    }
    """
    result = {}

    conn = None
    try:
        conn = await asyncpg.connect(
            host=settings.POSTGRES_HOST,
            port=int(settings.POSTGRES_PORT),
            user=settings.POSTGRES_USER,
            password=settings.POSTGRES_PASSWORD,
            database=settings.POSTGRES_DB,
        )
        await conn.set_type_codec('json',  schema='pg_catalog',
                          encoder=json.dumps, decoder=json.loads, format='text')
        await conn.set_type_codec('jsonb', schema='pg_catalog',
                          encoder=json.dumps, decoder=json.loads, format='text')

        rows = await conn.fetch("""
            SELECT server_name, url, transport, headers
            FROM agent_config
            WHERE agent_name = $1
        """, agent_name)

        for row in rows:
            server_name = row["server_name"]
            server_url = row["url"]
            transport = row["transport"]
            headers = row["headers"] or {}
            
            headers["X-Agent-Session-Id"] = agent_session_id
            
            result[server_name] = {
                "url": server_url,
                "transport": transport,  
                "headers": headers,      
            }
    except Exception as e:
        print(f"[get_mcp_config:postgres][ERROR] {e}")
    finally:
        if conn:
            await conn.close()

    return result

async def get_tool_list(agent_name: str, agent_session_id: str):
    config_mcp_server = await get_mcp_config(agent_name,agent_session_id)

    if not config_mcp_server:
        raise RuntimeError("No MCP servers configured")

    client = MultiServerMCPClient(config_mcp_server)
    tools_list = await client.get_tools()

    return tools_list

