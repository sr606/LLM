import os
# from dotenv import load_dotenv
from settings import settings
from fastapi import HTTPException, status, Security
from fastapi.security import APIKeyHeader
from keycloak import KeycloakOpenID
import json

# load_dotenv()


def user_auth(user_id):
    keycloak_openid = KeycloakOpenID(
        server_url=settings.SERVER_URL, 
        client_id=settings.CLIENT_ID,             
        realm_name=settings.REALM_NAME,        
        client_secret_key=settings.CLIENT_SECRET_KEY, 
    )


    token = keycloak_openid.token(user_id["user_name"], user_id["password"])

    userinfo = keycloak_openid.userinfo(token['access_token'])
    return userinfo

api_key_header = APIKeyHeader(
    name="X-API-Key",
    auto_error=False
)

with open('./data/api_key_store.json', 'r') as api_key_store:
    API_KEY_STORE = json.load(api_key_store)

async def get_current_user(
    api_key: str = Security(api_key_header)
) -> str:
    if not api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API key missing",
        )

    user_id = API_KEY_STORE.get(api_key)
    userinfo = user_auth(user_id)
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid API key",
        )

    return userinfo

if __name__ == '__main__':
    import asyncio
    # api_Key = settings.AGENT_API_KEY
    user = asyncio.run( get_current_user(settings.AGENT_API_KEY))
    print(user)