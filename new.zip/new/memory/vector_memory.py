# memory/vector_memory.py
import os
from typing import Optional
import faiss
from pydantic import SecretStr
from langchain_community.vectorstores.faiss import FAISS
from langchain_community.docstore.in_memory import InMemoryDocstore
from langchain_classic.memory import VectorStoreRetrieverMemory
from langchain_openai import AzureOpenAIEmbeddings  # or OpenAIEmbeddings

FAISS_DIR = "./data/faiss_memory"


def _embeddings():
    """
    Use your Azure embeddings.
    Make sure AZURE_OPENAI_EMBEDDING_DEPLOYMENT is set in settings.
    """
    from settings import settings
    return AzureOpenAIEmbeddings(
        azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
        api_key=SecretStr(settings.AZURE_OPENAI_API_KEY) if settings.AZURE_OPENAI_API_KEY else None,
        api_version=settings.AZURE_OPENAI_API_VERSION,
        azure_deployment=settings.AZURE_OPENAI_EMBEDDING_DEPLOYMENT,
    )


def _empty_faiss(emb) -> FAISS:
    """
    Create an empty FAISS index with correct vector dimension by probing the embedding model.
    """
    # Probe dimension once
    dim = len(emb.embed_query("dimension probe"))
    index = faiss.IndexFlatL2(dim)
    docstore = InMemoryDocstore({})
    index_to_docstore_id = {}
    return FAISS(emb, index, docstore, index_to_docstore_id)


def create_or_load_faiss() -> FAISS:
    emb = _embeddings()
    if os.path.isdir(FAISS_DIR) and os.listdir(FAISS_DIR):
        # Load existing index
        return FAISS.load_local(FAISS_DIR, emb, allow_dangerous_deserialization=True)
    # Create a brand-new, empty index
    return _empty_faiss(emb)


def make_memory(k: int = 3) -> VectorStoreRetrieverMemory:
    vs = create_or_load_faiss()
    retriever = vs.as_retriever(search_kwargs={"k": k})
    return VectorStoreRetrieverMemory(retriever=retriever)


def persist(vs: FAISS) -> None:
    os.makedirs(FAISS_DIR, exist_ok=True)
    vs.save_local(FAISS_DIR)