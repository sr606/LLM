import asyncio
from settings import settings
import httpx

async def stream_chat(payload):
    headers = {
        "X-API-Key": settings.AGENT_API_KEY
    }

    async with httpx.AsyncClient(timeout=None) as client:
        async with client.stream(
            "POST",
            settings.AGENT_API_BASE,
            json=payload,
            headers=headers
        ) as response:

            if response.status_code != 200:
                error_text = await response.aread()
                print("Error:", error_text.decode())
                return

            async for chunk in response.aiter_text():
                if chunk:
                    print(chunk, end="", flush=True)


if __name__ == "__main__":
    # payload = {
    #     "query": "can you calculate the sum of 25 and 62?",
    #     # "query": "list me the tools available ?",
    #     "thread_id": "1004",
    #     "agent_name": "test3",
    #     "temperature":0.00,
    #     "model_source":'azure'
    # }

    # asyncio.run(stream_chat(payload))


    payload = {
        "query": "Do you know story of meera?",
        # "query": "list me the tools available ?",
        "thread_id": "1005",
        "agent_name": "test3",
        "temperature":0.00,
        "model_source":'aws'
    }

    asyncio.run(stream_chat(payload))