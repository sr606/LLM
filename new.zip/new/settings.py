from dataclasses import dataclass
import os
from typing import Optional
from dotenv import load_dotenv
load_dotenv()

 
def _bool_from_str(s: Optional[str], default: bool = False) -> bool:
    if s is None:
        return default
    return str(s).strip().lower() in ("1", "true", "yes", "on")
 
 
@dataclass(frozen=True)
class Settings:

    TRACE_URL: str
    PHOENIX_API_KEY: str
    AGENT_API_BASE: str
    AGENT_API_KEY: str

    AGENT_MCP_URL: Optional[str]
    DB_URI: Optional[str]
 
    POSTGRES_HOST: str
    POSTGRES_PORT: int
    POSTGRES_DB: str
    POSTGRES_USER: Optional[str]
    POSTGRES_PASSWORD: Optional[str]
 
    AZURE_OPENAI_API_KEY: Optional[str]
    AZURE_OPENAI_ENDPOINT: Optional[str]
    AZURE_OPENAI_API_VERSION: Optional[str]
    AZURE_OPENAI_CHAT_DEPLOYMENT_NAME: Optional[str]
    AZURE_OPENAI_EMBEDDING_DEPLOYMENT: Optional[str]
 
    AWS_ACCESS_KEY_ID: Optional[str]
    AWS_SECRET_ACCESS_KEY: Optional[str]
    AWS_DEFAULT_REGION: Optional[str]
    AWS_CHAT_DEPLOYMENT_NAME: Optional[str]
 
    PARALLEL_TOOL_CALLS: bool
    RECURSION_LIMIT: int
 
    SERVER_URL: Optional[str]
    CLIENT_ID: Optional[str]
    REALM_NAME: Optional[str]
    CLIENT_SECRET_KEY: Optional[str]
    BASE_URL: Optional[str]
 
 
def load_settings() -> Settings:

    trace_url = os.environ["TRACE_URL"]
    phoenix_api_key = os.environ["PHOENIX_API_KEY"]
    agent_api_base = os.environ["AGENT_API_BASE"]
    agent_api_key = os.environ["AGENT_API_KEY"]

    agent_mcp_url = os.environ.get("AGENT_MCP_URL")
    db_uri = os.environ.get("DB_URI")
 
    pg_host = os.environ.get("POSTGRES_HOST", "localhost")
    pg_port = int(os.environ.get("POSTGRES_PORT", "5432"))
    pg_db = os.environ.get("POSTGRES_DB", "omnicore")
    pg_user = os.environ.get("POSTGRES_USER")
    pg_pass = os.environ.get("POSTGRES_PASSWORD")
 
    azure_key = os.environ.get("AZURE_OPENAI_API_KEY")
    azure_endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
    azure_version = os.environ.get("AZURE_OPENAI_API_VERSION")
    azure_chat = os.environ.get("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")
    azure_deployment=os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT")

    aws_key = os.environ.get("AWS_ACCESS_KEY_ID")
    aws_secret = os.environ.get("AWS_SECRET_ACCESS_KEY")
    aws_region = os.environ.get("AWS_DEFAULT_REGION")
    aws_chat = os.environ.get("AWS_CHAT_DEPLOYMENT_NAME")
 
    parallel = _bool_from_str(os.environ.get("PARALLEL_TOOL_CALLS", "false"), default=False)
    recursion = int(os.environ.get("RECURSION_LIMIT", "5"))
 
    server_url = os.environ.get("SERVER_URL")
    client_id = os.environ.get("CLIENT_ID")
    realm = os.environ.get("REALM_NAME")
    client_secret = os.environ.get("CLIENT_SECRET_KEY")
    base_url = os.environ.get("BASE_URL")
 
    return Settings(
        TRACE_URL=trace_url,
        PHOENIX_API_KEY=phoenix_api_key,
        AGENT_API_BASE=agent_api_base,
        AGENT_API_KEY=agent_api_key,
        AGENT_MCP_URL=agent_mcp_url,
        DB_URI=db_uri,
        POSTGRES_HOST=pg_host,
        POSTGRES_PORT=pg_port,
        POSTGRES_DB=pg_db,
        POSTGRES_USER=pg_user,
        POSTGRES_PASSWORD=pg_pass,
        AZURE_OPENAI_API_KEY=azure_key,
        AZURE_OPENAI_ENDPOINT=azure_endpoint,
        AZURE_OPENAI_API_VERSION=azure_version,
        AZURE_OPENAI_CHAT_DEPLOYMENT_NAME=azure_chat,
        AZURE_OPENAI_EMBEDDING_DEPLOYMENT=azure_deployment,
        AWS_ACCESS_KEY_ID=aws_key,
        AWS_SECRET_ACCESS_KEY=aws_secret,
        AWS_DEFAULT_REGION=aws_region,
        AWS_CHAT_DEPLOYMENT_NAME=aws_chat,
        PARALLEL_TOOL_CALLS=parallel,
        RECURSION_LIMIT=recursion,
        SERVER_URL=server_url,
        CLIENT_ID=client_id,
        REALM_NAME=realm,
        CLIENT_SECRET_KEY=client_secret,
        BASE_URL=base_url,
    )
 

settings = load_settings()