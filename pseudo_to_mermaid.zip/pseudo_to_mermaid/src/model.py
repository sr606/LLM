from dataclasses import dataclass, field
from typing import List, Dict

@dataclass
class Stage:
    name: str
    stage_type: str
    outputs: List[str] = field(default_factory=list)

@dataclass
class Link:
    source: str
    target: str
    label: str = "link"

@dataclass
class JobModel:
    job_name: str
    stages: Dict[str, Stage]
    links: List[Link]
