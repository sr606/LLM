import re
from src.model import JobModel, Stage, Link


def parse_pseudocode(text: str) -> JobModel:
    job_name = "UNKNOWN_JOB"
    stages = {}
    links = []

    current_stage = None

    for line in text.splitlines():
        line = line.strip()

        # Job name
        if line.startswith("// Record ROOT:"):
            job_name = line.split(":", 1)[1].strip()

        # Stage definition
        elif line.startswith("// Stage:"):
            match = re.search(r"// Stage:\s*(.*?)\s*\((.*?)\)", line)
            if match:
                stage_name, stage_type = match.groups()
                current_stage = stage_name
                stages[stage_name] = Stage(
                    name=stage_name,
                    stage_type=stage_type
                )

        # Link partner
        elif "Partner =" in line and current_stage:
            raw_partner = line.split("=", 1)[1].strip()

            partner_stage = raw_partner.split("|")[0]

            links.append(
                Link(
                    source=current_stage,
                    target=partner_stage,
                    label="lookup / link"
                )
            )

        # Output file
        elif "FileName =" in line and current_stage:
            filename = line.split("=", 1)[1].strip()
            stages[current_stage].outputs.append(filename)

    return JobModel(
        job_name=job_name,
        stages=stages,
        links=links
    )
