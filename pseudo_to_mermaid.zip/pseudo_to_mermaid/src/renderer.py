from pyvis.network import Network
from src.model import JobModel


def render_diagram(model: JobModel, output_html: str):
    # -------------------------
    # Create network
    # -------------------------
    net = Network(
        height="900px",
        width="100%",
        directed=True,
        bgcolor="#ffffff",
        font_color="black"
    )

    # -------------------------
    # Job node (context only)
    # -------------------------
    net.add_node(
        "JOB",
        label=f"{model.job_name}\n(DataStage Job)",
        shape="box",
        color="#E3F2FD"
    )

    # -------------------------
    # Add stage nodes
    # -------------------------
    for stage in model.stages.values():

        stype = stage.stage_type.lower()
        shape = "ellipse"
        color = "#FFF3E0"

        if "transformer" in stype or "sort" in stype:
            shape = "diamond"
            color = "#F8BBD0"
        elif "hashedfile" in stype:
            shape = "database"
            color = "#BBDEFB"
        elif "file" in stype or "output" in stype:
            shape = "database"
            color = "#E8F5E9"
        elif "input" in stype:
            shape = "database"
            color = "#FFF3E0"

        net.add_node(
            stage.name,
            label=f"{stage.name}\n({stage.stage_type})",
            shape=shape,
            color=color
        )

        # Output files (if any)
        for out in stage.outputs:
            out_node = f"{stage.name}_OUT"

            net.add_node(
                out_node,
                label=out,
                shape="box",
                color="#E8F5E9"
            )

            net.add_edge(
                stage.name,
                out_node,
                label="writes"
            )

    sources = []
    transforms = []
    targets = []

    for stage in model.stages.values():
        name = stage.name.lower()
        stype = stage.stage_type.lower()

    # SOURCE
        if "input" in name or "source" in name:
            sources.append(stage.name)

    # TRANSFORM
        elif "sort" in name or "transform" in name or "transformer" in stype:
            transforms.append(stage.name)

    # TARGET
        elif "output" in name or "file" in name or "target" in name:
            targets.append(stage.name)

# Fallback safety (very important)
# If no explicit transform found, connect source → target directly
    if not transforms:
        for src in sources:
            for tgt in targets:
                if src in net.get_nodes() and tgt in net.get_nodes():
                    net.add_edge(src, tgt, label="data flow")
    else:
        for src in sources:
            for tr in transforms:
                if src in net.get_nodes() and tr in net.get_nodes():
                    net.add_edge(src, tr, label="data flow")

    # Transform → Target
        for tr in transforms:
            for tgt in targets:
                if tr in net.get_nodes() and tgt in net.get_nodes():
                    net.add_edge(tr, tgt, label="data flow")


    # -------------------------
    # Layout (STRICT JSON)
    # -------------------------
    net.set_options("""
    {
      "layout": {
        "hierarchical": {
          "enabled": true,
          "direction": "UD",
          "levelSeparation": 160,
          "nodeSpacing": 240
        }
      },
      "physics": {
        "enabled": false
      },
      "edges": {
        "arrows": {
          "to": { "enabled": true }
        },
        "smooth": { "enabled": false },
        "font": { "size": 12 }
      }
    }
    """)

    # -------------------------
    # Write HTML safely
    # -------------------------
    net.write_html(
        output_html,
        notebook=False,
        open_browser=False
    )
