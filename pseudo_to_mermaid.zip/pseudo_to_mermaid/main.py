from src.parser import parse_pseudocode
from src.renderer import render_diagram

INPUT_FILE = "input/pseudocode.txt"
OUTPUT_FILE = "output/diagram.html"


def main():
    with open(INPUT_FILE, "r") as f:
        pseudocode = f.read()

    model = parse_pseudocode(pseudocode)
    render_diagram(model, OUTPUT_FILE)

    print(f"✅ Diagram generated: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
