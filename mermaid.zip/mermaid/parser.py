import re

def split_into_stages(text):

    pattern = r"// --- \[(.*?)\] \[Lines.*?\] ---([\s\S]*?)(?=// --- \[|$)"
    matches = re.findall(pattern, text)

    stages = []

    for header, body in matches:
        name_match = re.search(r":\s*(.*)", header)
        if not name_match:
            continue

        stage_id = name_match.group(1).strip()

        stages.append({
            "stage_id": stage_id,
            "block": body.strip()
        })

    return stages