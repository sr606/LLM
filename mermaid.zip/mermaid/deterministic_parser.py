from graphviz import Digraph

def render_drilldown(stages, output_path):

    dot = Digraph("Drilldown", format="pdf")
    dot.attr(rankdir="TB")

    for stage in stages:

        dataset_name = stage["outputs"][0] if stage["outputs"] else "NO_OUTPUT"

        header_id = f"HEADER_{dataset_name}"

        dot.node(header_id,
                 f"DATASET: {dataset_name}",
                 shape="box",
                 style="filled",
                 fillcolor="#90CAF9")

        stage_label = stage["stage_id"] + "\n"

        for join in stage["joins"]:
            stage_label += f"{join['join_type']} {join['table']}\n"
            stage_label += f"ON {join['condition']}\n"

        for t in stage["transformations"]:
            stage_label += f"{t['target']} ← {t['logic']}\n"

        dot.node(stage["stage_id"],
                 stage_label,
                 shape="box",
                 style="rounded,filled",
                 fillcolor="#FFE0B2")

        dot.edge(header_id, stage["stage_id"])

    dot.render(output_path, cleanup=True)