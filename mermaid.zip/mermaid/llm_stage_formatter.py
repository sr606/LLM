import os
import json
from dotenv import load_dotenv
from openai import AzureOpenAI
import re

load_dotenv()

client = AzureOpenAI(
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
)

DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT")


PROMPT = """
You are formatting ONE ETL stage for Graphviz HTML label.

STRICT RULES:
- Return ONLY HTML table rows (no <table> wrapper).
- Do NOT return markdown.
- Do NOT return explanations.
- Do NOT rename stage_id.
- Preserve all joins, filters, transformations.
- Keep full join conditions.
- Format clean and readable using <BR/> where needed.

Sections order:
1) PRIMARY TABLES
2) JOINS
3) FILTERS
4) TRANSFORMATIONS

Return HTML rows only like:
<TR><TD>...</TD></TR>
"""


def format_stage(stage_json):

    payload = json.dumps(stage_json, ensure_ascii=False)

    response = client.chat.completions.create(
        model=DEPLOYMENT,
        temperature=0.0,
        messages=[
            {"role": "system", "content": "You format ETL content cleanly."},
            {"role": "user", "content": PROMPT + "\n\nStage JSON:\n" + payload}
        ],
    )

    raw = response.choices[0].message.content or ""



    raw = re.sub(r"'''.*?'''", "", raw, flags=re.DOTALL)
    raw = raw.replace("'''html", "").replace("'''", "").strip()

    # return response.choices[0].message.content.strip()
    return raw