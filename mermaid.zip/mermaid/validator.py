def validate_stage(normalized, raw):

    sql_text = raw["sql"]
    transform_text = raw["transform"]

    # Validate joins
    valid_joins = []
    for j in normalized.get("joins", []):
        if j["condition"] in sql_text:
            valid_joins.append(j)

    normalized["joins"] = valid_joins[:3]

    # Validate transformations
    valid_transforms = []
    for t in normalized.get("transformations", []):
        if t["logic"] in transform_text:
            valid_transforms.append(t)

    normalized["transformations"] = valid_transforms[:6]

    return normalized