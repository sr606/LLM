from graphviz import Digraph
import textwrap


def wrap_text(text, width=80):
    lines = textwrap.wrap(text, width=width, break_long_words=False)
    return "<BR/>".join(lines)


def render_unified(stages, output_path):

    dot = Digraph("Unified", format="svg")
    dot.attr(rankdir="LR", splines="spline")

    previous_dataset = None

    for stage in stages:

        stage_id = stage["stage_id"]

        # ----------------------------
        # Build HTML Label
        # ----------------------------
        rows = []

        # Stage title
        rows.append(
            f'<TR><TD BGCOLOR="#FFE0B2"><B>{stage_id}</B></TD></TR>'
        )

        # Primary tables
        if stage.get("primary_tables"):
            rows.append('<TR><TD ALIGN="LEFT"><B>PRIMARY TABLE:</B></TD></TR>')
            for table in stage["primary_tables"]:
                rows.append(
                    f'<TR><TD ALIGN="LEFT">{wrap_text(table)}</TD></TR>'
                )

        # Joins
        if stage.get("joins"):
            rows.append('<TR><TD ALIGN="LEFT"><B>JOINS:</B></TD></TR>')
            for join in stage["joins"]:
                join_text = (
                    f"{join['join_type']} {join['table']}<BR/>"
                    f"ON {wrap_text(join['condition'])}"
                )
                rows.append(
                    f'<TR><TD ALIGN="LEFT">{join_text}</TD></TR>'
                )

        # Filters
        if stage.get("filters"):
            rows.append('<TR><TD ALIGN="LEFT"><B>FILTERS:</B></TD></TR>')
            for f in stage["filters"]:
                rows.append(
                    f'<TR><TD ALIGN="LEFT">{wrap_text(f)}</TD></TR>'
                )

        # Transformations
        if stage.get("transformations"):
            rows.append('<TR><TD ALIGN="LEFT"><B>TRANSFORMATIONS:</B></TD></TR>')
            for t in stage["transformations"]:
                transform_text = (
                    f"{t['target']} ← {wrap_text(t['logic'])}"
                )
                rows.append(
                    f'<TR><TD ALIGN="LEFT">{transform_text}</TD></TR>'
                )

        html_label = f"""<
        <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" WIDTH="600">
            {''.join(rows)}
        </TABLE>
        >"""

        dot.node(stage_id,
                 label=html_label,
                 shape="plaintext")

        # Connect datasets
        if previous_dataset:
            dot.edge(previous_dataset, stage_id)

        if stage.get("outputs"):
            ds = stage["outputs"][0]
            dot.node(ds,
                     f"""<
                     <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0">
                     <TR><TD BGCOLOR="#BBDEFB"><B>{ds}</B></TD></TR>
                     </TABLE>
                     >""",
                     shape="plaintext")

            dot.edge(stage_id, ds)
            previous_dataset = ds

    dot.render(output_path, cleanup=True)