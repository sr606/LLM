def build_lineage_model(stages):

    return stages
