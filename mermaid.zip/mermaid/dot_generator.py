# import os
# from dotenv import load_dotenv
# from openai import AzureOpenAI

# load_dotenv()

# client = AzureOpenAI(
#     api_key=os.getenv("AZURE_OPENAI_API_KEY"),
#     api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
#     azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
# )

# DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT")


# def generate_dot(workflow_name, stages):

#     prompt = f"""
# You are generating Graphviz DOT code.

# Rules:
# - Output ONLY valid DOT code.
# - No markdown.
# - No explanations.
# - Use digraph.
# - rankdir=LR.
# - Use subgraph cluster_workflow.
# - Use HTML table nodes.
# - Preserve ALL joins and transformations.
# - Do NOT invent new stages.
# - Use exact stage_id names.
# - Connect stages using outputs to inputs.
# - Style similar to Alteryx workflow.
# """

#     response = client.chat.completions.create(
#         model=DEPLOYMENT,
#         temperature=0.0,
#         messages=[
#             {"role": "system", "content": "You generate Graphviz DOT workflows."},
#             {
#                 "role": "user",
#                 "content": prompt + "\n\nWorkflow JSON:\n" + str({
#                     "workflow_name": workflow_name,
#                     "stages": stages
#                 })
#             }
#         ]
#     )

#     return response.choices[0].message.content.strip()


import os
import re
import json
import html
from dotenv import load_dotenv
from openai import AzureOpenAI

load_dotenv()

client = AzureOpenAI(
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
)

DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT")


_PROMPT_RULES = """
You are generating a Graphviz DOT workflow.
 
You MUST strictly follow this layout pattern:
 
digraph WORKFLOW_NAME {
  rankdir=TB;
  bgcolor="white";
  graph [fontname="Helvetica", fontsize=11, nodesep=0.8, ranksep=1.2];
  edge  [fontname="Helvetica", fontsize=9, color="#555555"];
  node  [shape=plain, fontname="Helvetica", fontsize=10];
 
  subgraph cluster_workflow {
    label="WORKFLOW_NAME";
    labelloc=t;
    fontsize=14;
    color="#90CAF9";
 
    // For each stage:
    STAGE_ID [
      label=<
<table border="0" cellborder="1" cellspacing="0" cellpadding="6" width="750">
<tr><td bgcolor="#FFE0B2"><b>STAGE_ID</b></td></tr>
<tr><td align="left">
            PRIMARY TABLE SECTION (if exists)
            JOINS SECTION (if exists)
            FILTERS SECTION (if exists)
            TRANSFORMATIONS SECTION (if exists)
</td></tr>
</table>
>
    ];
 
    // Connect stages vertically:
    STAGE_1 -> STAGE_2;
    STAGE_2 -> STAGE_3;
  }
}
 
STRICT RULES:
- Use rankdir=TB.
- Use EXACT stage_id names.
- Do NOT rename nodes.
- Do NOT invent stages.
- Do NOT omit any stage.
- Preserve ALL joins and transformations.
- Keep full join conditions.
- Use HTML label syntax exactly as shown.
- Use literal < and > characters.
- Output ONLY valid DOT.
"""

def _strip_code_fences(s: str) -> str:
    """Remove any Markdown code fences if present."""
    # Remove any leading/trailing ```... fences (language optional)
    # Use a conservative approach across the whole text.
    fence_pattern = re.compile(r"^\s*```[a-zA-Z0-9]*\s*|\s*```\s*$", re.MULTILINE)
    s = fence_pattern.sub("", s)
    return s.strip()


def _extract_dot_block(s: str) -> str:
    """
    From a possibly noisy response, extract the DOT block that starts with
    'digraph' or 'graph' and ends at the last closing brace.
    """
    s = s.strip()
    # Find the start of the graph
    m = re.search(r"(digraph|graph)\s+[^\{]*\{", s, flags=re.DOTALL)
    if not m:
        return s  # best effort; sanity check will catch this later
    start = m.start()

    # Heuristic: take everything up to the last '}' in the text
    end = s.rfind("}")
    if end == -1:
        return s[start:].strip()
    return s[start:end + 1].strip()

def _clean_and_validate(dot_text: str) -> str:
    """
    - Strip code fences
    - Unescape HTML entities to literal characters
    - Extract only the DOT block
    - Validate it begins with digraph/graph
    """
    # 1) Strip code fences
    dot_text = _strip_code_fences(dot_text)

    # 2) Unescape &lt; &gt; &amp; etc.
    dot_text = html.unescape(dot_text)

    # 3) Extract only the DOT block
    dot_text = _extract_dot_block(dot_text)

    # 4) Final sanity checks
    if not dot_text.lstrip().startswith(("digraph", "graph")):
        raise ValueError("DOT must start with 'digraph' or 'graph'. Got:\n" + dot_text[:120])

    # Quick guard against accidental markdown remnants
    if "```" in dot_text or "LLM RAW RESPONSE" in dot_text:
        raise ValueError("DOT contains unexpected markdown/log text. Clean the generator output.")

    return dot_text


def generate_dot(workflow_name, stages):
    """
    Returns clean DOT text, safe to feed to graphviz.Source(...).
    """
    # Build a clean JSON payload for the model (avoid Python dict repr)
    payload = json.dumps({
        "workflow_name": workflow_name,
        "stages": stages
    }, ensure_ascii=False)

    messages = [
        {"role": "system", "content": "You generate strictly valid Graphviz DOT workflows."},
        {"role": "user", "content": _PROMPT_RULES + "\n\nWorkflow JSON:\n" + payload}
    ]

    response = client.chat.completions.create(
        model=DEPLOYMENT,
        temperature=0.0,
        messages=messages,
        # Optional: discourage markdown fences
        stop=["```"]
    )

    raw = response.choices[0].message.content or ""

    print("\n=== RAW LLM OUTPUT===\n")
    print(raw)
    print("\n=================\n")
    cleaned = _clean_and_validate(raw)

    # Optional: extra assert for HTML-like labels usage
    # Not strictly required, but useful to ensure <table> labels pass through.
    # if "&lt;" in cleaned or "&gt;" in cleaned:
    #     raise ValueError("Found HTML-escaped angle brackets. The DOT must use literal '<' and '>' in label=<...>.")

    return cleaned