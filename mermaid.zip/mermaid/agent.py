

import os
from parser import split_into_stages
from extractor import extract_raw_blocks
from llm_normalizer import normalize_stage
from validator import validate_stage
import json
import re

# NEW: use stage formatter + vertical builder instead of DOT generator
from llm_stage_formatter import format_stage
from dot_builder import build_vertical_workflow

INPUT_FOLDER = "data/input"
OUTPUT_FOLDER = "data/output"


def process_file(file_path: str, file_name: str):
    """
    Processes a single pseudocode .txt file:
      - splits into stages
      - extracts raw blocks
      - normalizes/validates
      - prepares html_rows for each stage
      - builds a vertical workflow diagram
    """
    with open(file_path, "r", encoding="utf-8") as f:
        pseudo = f.read()

    print(f"Processing: {file_name}")

    stages = split_into_stages(pseudo)
    final_stages = []

    for stage in stages:
        # 1) Extract raw blocks from the stage block text
        raw = extract_raw_blocks(stage["block"])

        # 2) Normalize with the LLM layer
        normalized = normalize_stage(stage["stage_id"], raw)

        print("\n==RAW BLOCK==")
        print(json.dumps(raw, indent=2))

        print("\n ---AFTER normalize----")
        print(json.dumps(normalized, indent=2))

        # 3) Merge structural info (inputs/outputs) back to normalized
        normalized["inputs"] = raw.get("inputs", [])
        normalized["outputs"] = raw.get("outputs", [])

        # 4) Validate the stage vs raw
        # validated = validate_stage(normalized, raw)
        final_stages.append(normalized)

    # Use base name to name outputs
    base = file_name.replace(".txt", "")

    # Optional: deterministic ordering for stable diagrams
    final_stages = sorted(final_stages, key=lambda x: x["stage_id"])


    # 5) Prepare HTML rows for each stage (consumed by dot_builder)
    for stage in final_stages:
        print("\n====== STAGE JSON SENT TO LLM======")
        print(json.dumps(final_stages, indent=2))
        print("\n==================================")
        # format_stage should return the HTML rows/blocks required by dot_builder
        stage["html_rows"] = format_stage(stage)

    # 6) Build the vertical workflow diagram
    # The builder will create files under the provided base path (without extension)
    output_base_path = os.path.join(OUTPUT_FOLDER, f"{base}_vertical")
    build_vertical_workflow(final_stages, output_base_path)

    print(f"Rendered vertical workflow at base: {output_base_path}\n")


def run_agent():
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)

    if not os.path.isdir(INPUT_FOLDER):
        raise FileNotFoundError(f"Input folder not found: {INPUT_FOLDER}")

    files = [f for f in os.listdir(INPUT_FOLDER) if f.endswith(".txt")]
    if not files:
        print(f"No .txt files found in {INPUT_FOLDER}")
        return

    for file in files:
        file_path = os.path.join(INPUT_FOLDER, file)
        try:
            process_file(file_path, file)
        except Exception as e:
            # Don’t fail the whole run for one file; log and continue
            print(f"[ERROR] Failed to process {file}: {e}")

    print("Done.")


if __name__ == "__main__":
    run_agent()