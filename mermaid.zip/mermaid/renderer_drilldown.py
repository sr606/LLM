from graphviz import Digraph
import textwrap


def wrap_text(text, width=80):
    lines = textwrap.wrap(text, width=width, break_long_words=False)
    return "<BR/>".join(lines)


def render_drilldown(stages, output_path):

    dot = Digraph("Drilldown", format="svg")
    dot.attr(rankdir="TB", splines="spline")

    for stage in stages:

        dataset_name = stage["outputs"][0] if stage["outputs"] else "NO_OUTPUT"

        # ----------------------------
        # Dataset Header Box
        # ----------------------------
        header_id = f"HEADER_{dataset_name}"

        header_label = f"""<
        <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" WIDTH="700">
            <TR>
                <TD BGCOLOR="#90CAF9">
                    <B>DATASET: {dataset_name}</B>
                </TD>
            </TR>
        </TABLE>
        >"""

        dot.node(header_id,
                 label=header_label,
                 shape="plaintext")

        # ----------------------------
        # Stage Detail Box
        # ----------------------------
        rows = []

        rows.append(
            f'<TR><TD BGCOLOR="#FFE0B2"><B>{stage["stage_id"]}</B></TD></TR>'
        )

        if stage.get("primary_tables"):
            rows.append('<TR><TD ALIGN="LEFT"><B>PRIMARY TABLE:</B></TD></TR>')
            for table in stage["primary_tables"]:
                rows.append(
                    f'<TR><TD ALIGN="LEFT">{wrap_text(table)}</TD></TR>'
                )

        if stage.get("joins"):
            rows.append('<TR><TD ALIGN="LEFT"><B>JOINS:</B></TD></TR>')
            for join in stage["joins"]:
                join_text = (
                    f"{join['join_type']} {join['table']}<BR/>"
                    f"ON {wrap_text(join['condition'])}"
                )
                rows.append(
                    f'<TR><TD ALIGN="LEFT">{join_text}</TD></TR>'
                )

        if stage.get("filters"):
            rows.append('<TR><TD ALIGN="LEFT"><B>FILTERS:</B></TD></TR>')
            for f in stage["filters"]:
                rows.append(
                    f'<TR><TD ALIGN="LEFT">{wrap_text(f)}</TD></TR>'
                )

        if stage.get("transformations"):
            rows.append('<TR><TD ALIGN="LEFT"><B>TRANSFORMATIONS:</B></TD></TR>')
            for t in stage["transformations"]:
                transform_text = (
                    f"{t['target']} ← {wrap_text(t['logic'])}"
                )
                rows.append(
                    f'<TR><TD ALIGN="LEFT">{transform_text}</TD></TR>'
                )

        stage_label = f"""<
        <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" WIDTH="700">
            {''.join(rows)}
        </TABLE>
        >"""

        dot.node(stage["stage_id"],
                 label=stage_label,
                 shape="plaintext")

        dot.edge(header_id, stage["stage_id"])

    dot.render(output_path, cleanup=True)