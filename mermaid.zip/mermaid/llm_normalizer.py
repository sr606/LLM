import os
import json
from dotenv import load_dotenv
from openai import AzureOpenAI

load_dotenv()

client = AzureOpenAI(
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT")
)

DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT")


def normalize_stage(stage_id, raw):

    prompt = f"""
Extract structured lineage.

Return STRICT JSON only:

{{
  "stage_id": "{stage_id}",
  "primary_tables": [],
  "joins": [
    {{
      "join_type": "",
      "table": "",
      "condition": ""
    }}
  ],
  "filters": [],
  "transformations": [
    {{
      "target": "",
      "logic": ""
    }}
  ]
}}

Rules:
- Extract top-level primary table from first FROM
- Extract max 3 joins
- Extract max 6 transformations
- Ignore nested subqueries
- Copy text exactly from input
"""

    response = client.chat.completions.create(
        model=DEPLOYMENT,
        temperature=0.0,
        messages=[
            {"role": "system", "content": "You extract SQL lineage strictly."},
            {"role": "user", "content": prompt + "\nSQL:\n" + raw["sql"] + "\nTRANSFORM:\n" + raw["transform"]}
        ]
    )

    content = response.choices[0].message.content.strip()

    print("\nLLM RAW RESPONSE:\n", content)

    try:
        return json.loads(content)
    except:
        return {
            "stage_id": stage_id,
            "primary_tables": [],
            "joins": [],
            "filters": [],
            "transformations": []
        }