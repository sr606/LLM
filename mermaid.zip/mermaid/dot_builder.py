
from graphviz import Digraph


def build_vertical_workflow(stages, output_path):

    dot = Digraph("Workflow", format="pdf")
    dot.attr(rankdir="TB")
    dot.node_attr.update(shape="plaintext")

    previous_node = None

    for stage in stages:

        stage_id = stage["stage_id"]

        html_label = f"""
        <
        <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" WIDTH="900">
            <TR>
                <TD BGCOLOR="#FFE0B2"><B>{stage_id}</B></TD>
            </TR>
            {stage["html_rows"]}
        </TABLE>
        >
        """

        dot.node(stage_id, label=html_label)

        if previous_node:
            dot.edge(previous_node, stage_id)

        previous_node = stage_id

    dot.render(output_path, cleanup=True)