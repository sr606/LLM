import streamlit as st
import os
from dotenv import load_dotenv
import uuid
import httpx

load_dotenv()

st.title("Omnicore Agent-Verse")

API_URL = os.environ["AGENT_API_BASE"]
API_KEY = os.environ["AGENT_API_KEY"]

if "session_id" not in st.session_state:
    st.session_state.session_id = uuid.uuid4()

with st.sidebar:
    with st.expander("Configuration",expanded=True):
        temperature = st.slider("set the model temp :", min_value =0.0, max_value =1.0, step=0.01)
        model_source = st.radio(
            "Select your model provider",
            ["azure", "aws"],
            index=0,
        )
    with st.expander("Select your agent",expanded=True):
        agent_name = st.radio(
            "**Agent List**",
            ["test3", "file_details","db_details"],
            index=0,
        )

# feedback_mapping = ["good", "bad"]

async def get_response(m):
    payload = {
        "query": m,
        "thread_id": str(st.session_state.session_id).replace("-",""),
        "agent_name": agent_name,
        "temperature":temperature,
        "model_source":model_source
    }

    headers = {
        "X-API-Key": API_KEY
    }

    async with httpx.AsyncClient(timeout=None) as client:
        async with client.stream(
            "POST",
            API_URL,
            json=payload,
            headers=headers
        ) as response:

            if response.status_code != 200:
                error_text = await response.aread()
                yield {"Error:", error_text.decode()}

            async for chunk in response.aiter_text():
                if chunk:
                    yield chunk


# Initialize chat history
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display chat messages from history on app rerun
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])



# Accept user input
if prompt := st.chat_input("What is up?"):
    # Display user message in chat message container
    with st.chat_message("user"):
        st.markdown(prompt)
    with st.chat_message("assistant"):
        a_response = st.write_stream(get_response(prompt))

    # feedback_selected = st.feedback(options="thumbs")


    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})
    st.session_state.messages.append({"role": "assistant", "content":a_response })

# if feedback_selected is not None:
#     st.markdown(f"You selected: {feedback_mapping[feedback_selected]}")