import os
import asyncio
from dotenv import load_dotenv
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.prebuilt import ToolNode, tools_condition
from langchain_core.tools import tool
from langchain_core.messages import (
    SystemMessage,
    BaseMessage,
    HumanMessage,
    AIMessage,
    ToolMessage,
    AIMessageChunk
)
from langgraph.types import interrupt
from phoenix.client import Client
from langchain_core.runnables import RunnableConfig
import json
from llm_mgmt import session_llm as sl
from extractCodeBlock import extractCodeBlock
import routers.v1.agent_checkpointer as agent_checkpointer
from routers.v1.mcp_config import get_tool_list
from langchain_core.tools import StructuredTool
from typing import Any, Dict
from routers.v1.agent_state import State
from routers.v1.agent_nodes import (
    agent_call_node as agent_call_node_impl,
    llm_intel as llm_intel
)

load_dotenv()

# --------------------------------------------------------------------------
# PHOENIX TRACING SETUP
# --------------------------------------------------------------------------
trace_url = os.environ["TRACE_URL"]
phoenix_api_key = os.environ["PHOENIX_API_KEY"]
AGENT_API_BASE = os.environ["AGENT_API_BASE"]
AGENT_API_KEY = os.environ["AGENT_API_KEY"]
parallel_tool_calls = json.loads(os.environ["PARALLEL_TOOL_CALLS"].lower())
recursion_limit = int(os.environ["RECURSION_LIMIT"])


# --------------------------------------------------------------------------
# AGENT CONFIG SETUP
# --------------------------------------------------------------------------
agent_mcp_url = os.environ["AGENT_MCP_URL"]

def wrap_mcp_tool_with_agent_session(tool, agent_session_id: str):
    async def _arun(**kwargs: Dict[str, Any]):
        tool_input = dict(kwargs)
        tool_input["agent_session_id"] = agent_session_id
        return await tool.arun(tool_input)   # ✅ FIX

    def _run(**kwargs: Dict[str, Any]):
        tool_input = dict(kwargs)
        tool_input["agent_session_id"] = agent_session_id
        return tool.run(tool_input)           # ✅ FIX

    return StructuredTool.from_function(
        func=_run,
        coroutine=_arun,
        name=tool.name,
        description=tool.description,
        args_schema=tool.args_schema,  # MUST keep this
    )

# --------------------------------------------------------------------------
# TOOLS
# --------------------------------------------------------------------------

@tool
def calculator(a: int, b: int, operator: str):
    """Basic calculator tool.
    Args :
        a = the first number
        b = the second number
        operator = the name of the operation, e.g. : add, multiply etc.
    """
    if operator == 'add':
        return a + b
    if operator == 'multiply':
        return a * b
    if operator == 'subtract':
        return a - b
    if operator == 'divide':
        return a / b
    raise ValueError("Unsupported operator")

TOOLS = [calculator]

# --------------------------------------------------------------------------
# STARTING POINT
# --------------------------------------------------------------------------
async def create_agent(agent_name: str, model_source: str, thread_id: str):
    print("[agent.create_agent] agent_name:", repr(agent_name))  # <-- DEBUG
    if agent_checkpointer.checkpointer is None:
        raise RuntimeError("Postgres checkpointer not initialized")

    mcp_tools = await get_tool_list(agent_name, thread_id)
    tool_map = {
        "db_details": ['list_tables','get_schema','run_query'],
        "file_details": ['list_files']
    }


    agent_tools = tool_map.get(agent_name)
    sel_tool_list = []

    if agent_tools:
        for i in mcp_tools:
            if i.name.split('_v1_')[0] in agent_tools:
                sel_tool_list.append(i)
    
    wrapped_tools = []

    for tool in sel_tool_list:
        wrapped_tools.append(
            wrap_mcp_tool_with_agent_session(
                tool,
                agent_session_id=thread_id
            )
        )

    tools = TOOLS + wrapped_tools
    agent = PhoenixGraphAgent(agent_name, tools, model_source)

    agent.graph = agent.graph.compile(
        checkpointer=agent_checkpointer.checkpointer
    ).with_config({
        "run_name": agent_name,
        "parallel_tool_calls": parallel_tool_calls,
        "recursion_limit": recursion_limit
    })

    return agent

# --------------------------------------------------------------------------
# AGENT CLASS WITH USER_ID + PHOENIX TRACE
# --------------------------------------------------------------------------
class PhoenixGraphAgent:
    def __init__(self, agent_name: str,tools, model_source):
        self.agent_name = agent_name
        self.system_msg = self._get_system_prompt()
        self.model_source = model_source
        self.llm = sl.session_llm(model_source)
        self.tools = tools
        self.llm_with_tools = self.llm.bind_tools(self.tools)
        self.graph = self._build_graph()

    def is_text_a_dict(self, text: str) -> bool:
        """
        Check if a string is a JSON dict.
        Returns True if `text` can be parsed as a JSON dict, False otherwise.
        """
        if not isinstance(text, str):
            return False
        try:
            data = json.loads(text)
            if data["type"]=="Agent_Call":
                return True
            elif data["type"] == "feedback":
                return True
            else:
                return False 
        except (json.JSONDecodeError, TypeError):
            try:
                code_blocks = extractCodeBlock(text)
                data = json.loads(code_blocks[0]['json'])
                if data["type"] == "Agent_Call":
                    return True
                else:
                    return False
            except:
                return False 

    # ----------------------------------------------------------------------
    # LOAD SYSTEM PROMPT
    # ----------------------------------------------------------------------
    def _get_system_prompt(self) -> str:
        try:
            client = Client(
                base_url=os.getenv("BASE_URL"),
                api_key=os.getenv("PHOENIX_API_KEY")
            )
            prompt_name = self.agent_name.lower().strip()
            prompt = client.prompts.get(prompt_identifier=prompt_name)
            prompt_set = prompt._template["messages"]
            prompt_msg = next(
                (item["content"][0]["text"]
                for item in prompt_set if item.get("role") == "system"),
                None
            )
            if not prompt_msg:
                raise ValueError(f"Invalid system prompt for {self.agent_name}")
        except Exception as e:
            print(e)
            prompt_msg = "You are an intelligent agent."
        return prompt_msg

    # ----------------------------------------------------------------------
    # NODE INITIALIZATION
    # ----------------------------------------------------------------------
    async def msg_clasify(self, state: State, config: RunnableConfig):
        last_msg = state["messages"][-1]
        print("feedback received for", last_msg)
        return

    async def llm_intel(self, state: State, config: RunnableConfig):
        async for event in llm_intel(
            state,
            config,
            llm_with_tools=self.llm_with_tools,
            system_msg=self.system_msg,
        ):
            yield event

    async def agent_call_node(self, state: State, config: RunnableConfig):
        async for event in agent_call_node_impl(
            state,
            config,
            model_source=self.model_source,
            temperature=self.temperature,
        ):
            yield event

    async def msg_clasify_condition(self, state: State, config: RunnableConfig):
        last_msg = state["messages"][-1]

        if isinstance(last_msg, HumanMessage) and self.is_text_a_dict(last_msg.content):
            return "feedback"

        return "next"

    async def tools_condition(self, state: State, config: RunnableConfig):
        last_msg = state["messages"][-1]

        # 1. Tool calls only exist on AIMessage
        if isinstance(last_msg, AIMessage) and last_msg.tool_calls:
            return "tool_calls"

        # 2. Agent delegation check (string-based)
        if isinstance(last_msg.content, str) and self.is_text_a_dict(last_msg.content):
            return "Agent_Call"

        return "next"

    # ----------------------------------------------------------------------
    # BUILD GRAPH
    # ----------------------------------------------------------------------
    def _build_graph(self):
        tool_node = ToolNode(tools=self.tools)
        graph_builder = StateGraph(State)

        graph_builder.add_node("llm_intel", self.llm_intel)
        graph_builder.add_node("tools", tool_node)
        graph_builder.add_node("agent_call", self.agent_call_node)
        graph_builder.add_node("msg_clasify", self.msg_clasify)

        # graph_builder.add_edge(START, "llm_intel")

        graph_builder.add_conditional_edges(
            START,
            self.msg_clasify_condition,
            {
                "feedback": "msg_clasify",
                "next": "llm_intel"
            }
        )        

        graph_builder.add_conditional_edges(
            "llm_intel",
            self.tools_condition,
            {
                "tool_calls": "tools",
                "Agent_Call": "agent_call",
                "next": END
            }
        )

        graph_builder.add_edge("tools", "llm_intel")
        graph_builder.add_edge("agent_call", "llm_intel")
        graph_builder.add_edge("msg_clasify", END)

        return graph_builder

    # ----------------------------------------------------------------------
    # RUN
    # ----------------------------------------------------------------------
    async def run(self, message: str, thread_id: str, user_id: str, temperature: float = 0.0):
        config = {
            "configurable": {
                "thread_id": thread_id,
                "user_id": user_id,
                "llm_temperature": temperature,
            }
        }
        self.temperature = temperature

        async for event in self.graph.astream_events(
            {"messages": [HumanMessage(content=message)]},
            config,
            version= "v2",
            stream_mode=["messages"]
        ):
            yield event

# --------------------------------------------------------------------------
# MAIN EXAMPLE
# --------------------------------------------------------------------------
if __name__ == "__main__":
    async def main():
        agent = await create_agent("test2",'azure')

        # msgs = [
        #     "who is charlie chaplin in 1 line?",
        #     "when did he die?",
        #     "can you calculate the sum of 2 and 6 and then deduct 4 from it?",
        #     "what is the highest score of sachin tendulkar?",
        # ]

        # msgs = ["what are the tools available ?",
        #         "list me all the tables and their schemas."]

        # msgs = [
        #     "when did he retire from ODI?",
        #     "can you write me a code to identify palindrome strings."
        # ]

        # msgs = ["list me all the tables and their schemas."]

        msgs = ["who is charlie chaplin in 1 line?",
                "can you calculate the sum of 2 and 6 and then deduct 4 from it?",
                ]

        # msgs = ["can you calculate the sum of 25 and 62 and then deduct 41 from it?"]
        
        for m in msgs:
            print("\nUSER:", m)
            async for event in agent.run(
                message=m,
                thread_id="1004",
                user_id="user_abc_004",
                temperature=0.0
            ):
                if event["event"] == "on_chat_model_stream":
                    content = event["data"]["chunk"].content

                    # Case 1: content is a string
                    if isinstance(content, str):
                        print(content, end="", flush=True)

                    # Case 2: content is a list (e.g. [{"text": "..."}])
                    elif isinstance(content, list) and content:
                        value = content[0].get("text")
                        if value:
                            print(value, end="", flush=True)

                    # Case 3: content is None → do nothing safely
                    elif content is None:
                        pass


                if event["event"] == "on_tool_end":
                    metadata = event["data"].get("metadata", {}) or {}

                    mcp_session_id = (
                        metadata.get("mcp_session_id")
                        or metadata.get("session_id")
                        or metadata.get("mcp", {}).get("session_id")
                    )

                    if mcp_session_id:
                        print(f"[MCP SESSION ENDED] session_id={mcp_session_id}")

                    print(f'\ninput : {event["data"]["input"]}')
                    print(f'output : {event["data"]["output"].content}')

    asyncio.run(main())
