import os
from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langchain_core.runnables import ConfigurableField


load_dotenv()

def session_llm(model_source: str):
    
 
    if model_source == "azure":

        AZURE_OPENAI_API_KEY = os.environ["AZURE_OPENAI_API_KEY"]
        AZURE_OPENAI_ENDPOINT = os.environ["AZURE_OPENAI_ENDPOINT"]
        AZURE_OPENAI_API_VERSION = os.environ["AZURE_OPENAI_API_VERSION"]
        AZURE_OPENAI_CHAT_DEPLOYMENT_NAME = os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"]

 
        llm = init_chat_model(
            model=AZURE_OPENAI_CHAT_DEPLOYMENT_NAME,
            model_provider="azure_openai",
            azure_deployment=AZURE_OPENAI_CHAT_DEPLOYMENT_NAME,
            openai_api_version=AZURE_OPENAI_API_VERSION,
            verbose=True,
        )
 
    elif model_source == "aws":
        # AWS credentials
        AWS_ACCESS_KEY_ID = os.environ["AWS_ACCESS_KEY_ID"] 
        AWS_SECRET_ACCESS_KEY = os.environ["AWS_SECRET_ACCESS_KEY"] 
        AWS_DEFAULT_REGION = os.environ["AWS_DEFAULT_REGION"]
        AWS_CHAT_DEPLOYMENT_NAME = os.environ["AWS_CHAT_DEPLOYMENT_NAME"]
 
        llm = init_chat_model(
            model= AWS_CHAT_DEPLOYMENT_NAME,
            model_provider="bedrock",
            region_name= AWS_DEFAULT_REGION,
            # streaming=True,
            max_tokens=65536,
        )
 
    else:
        raise ValueError("Invalid model_source")
 
    # ✅ SAME configurable behavior as your original code
    llm = llm.configurable_fields(
        temperature=ConfigurableField(
            id="llm_temperature",
            name="LLM Temperature",
            description="The temperature of the LLM",
        )
    )
 
    return llm
